# plugin.audio.spotify
Unofficial spotify plugin for Kodi
