"""CherryPy'd cherryd daemon runner."""
from cherrypy.daemon import run


__name__ == '__main__' and run()
