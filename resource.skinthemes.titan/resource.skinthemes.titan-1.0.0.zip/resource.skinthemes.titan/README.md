# resource.skinthemes.titan
Kodi resource addon with additional skin themes for the Titan skin
