#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
    script.tv.show.next.aired
    TV Show - Next Aired
    Main service entry point
'''

from resources.lib.main_service import MainService
MainService()
