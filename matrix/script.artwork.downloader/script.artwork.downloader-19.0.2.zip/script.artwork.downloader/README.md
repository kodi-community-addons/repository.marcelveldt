# script.artwork.downloader
This script can automaticly download all available artwork for your movies,  tvshows in your library.
