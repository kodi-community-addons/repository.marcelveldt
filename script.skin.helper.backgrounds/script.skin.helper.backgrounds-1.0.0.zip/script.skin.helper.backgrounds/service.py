#!/usr/bin/python
# -*- coding: utf-8 -*-

from resources.lib.backgrounds_updater import BackgroundsUpdater
BackgroundsUpdater().run()
