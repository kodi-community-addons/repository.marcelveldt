# plugin.audio.squeezebox
Squeezelite player for Kodi

________________________________________________________________________________________________________


Work in progress!
This project is not yet finished altough some basics should already work.

Includes squeezelite binary for both Windows and MacOS, for other platforms squeezelite (or other sw player) should be started manually before launching the addon.
